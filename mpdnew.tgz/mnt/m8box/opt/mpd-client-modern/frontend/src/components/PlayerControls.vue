<template>
  <div class="bg-gray-800 border-t border-gray-700 p-4">
    <div class="max-w-7xl mx-auto">
      <div class="flex items-center justify-between">
        <!-- Song Info -->
        <div class="flex items-center space-x-4 flex-1 min-w-0">
          <div class="w-12 h-12 bg-gray-600 rounded-lg flex items-center justify-center">
            <svg class="w-6 h-6 text-gray-300" fill="currentColor" viewBox="0 0 20 20">
              <path d="M18 3a1 1 0 00-1.196-.98l-10 2A1 1 0 006 5v9.114A4.369 4.369 0 005 14c-1.657 0-3 .895-3 2s1.343 2 3 2 3-.895 3-2V7.82l8-1.6v5.894A4.369 4.369 0 0015 12c-1.657 0-3 .895-3 2s1.343 2 3 2 3-.895 3-2V3z" />
            </svg>
          </div>
          <div class="min-w-0 flex-1">
            <p class="text-sm font-medium text-white truncate">
              {{ currentSong?.title || 'No song playing' }}
            </p>
            <p class="text-xs text-gray-400 truncate">
              {{ currentSong?.artist || '' }}
            </p>
          </div>
        </div>

        <!-- Controls -->
        <div class="flex items-center space-x-4">
          <button 
            @click="previous" 
            class="p-2 rounded-full hover:bg-gray-700 transition-colors"
            :disabled="!isConnected"
          >
            <svg class="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
              <path d="M8.445 14.832A1 1 0 0010 14v-2.798l5.445 3.63A1 1 0 0017 14V6a1 1 0 00-1.555-.832L10 8.798V6a1 1 0 00-1.555-.832l-6 4a1 1 0 000 1.664l6 4z" />
            </svg>
          </button>

          <button 
            @click="isPlaying ? pause() : play()" 
            class="p-3 rounded-full bg-blue-600 hover:bg-blue-700 transition-colors"
            :disabled="!isConnected"
          >
            <svg v-if="isPlaying" class="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 20 20">
              <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd" />
            </svg>
            <svg v-else class="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 20 20">
              <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clip-rule="evenodd" />
            </svg>
          </button>

          <button 
            @click="next" 
            class="p-2 rounded-full hover:bg-gray-700 transition-colors"
            :disabled="!isConnected"
          >
            <svg class="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
              <path d="M4.555 5.168A1 1 0 003 6v8a1 1 0 001.555.832L10 11.202V14a1 1 0 001.555.832l6-4a1 1 0 000-1.664l-6-4A1 1 0 0010 6v2.798l-5.445-3.63z" />
            </svg>
          </button>
        </div>

        <!-- Volume Control -->
        <div class="flex items-center space-x-2 w-32">
          <svg class="w-4 h-4 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M9.383 3.076A1 1 0 0110 4v12a1 1 0 01-1.617.804L4.586 13H2a1 1 0 01-1-1V8a1 1 0 011-1h2.586l3.797-3.804a1 1 0 011.617.804zM14.657 2.929a1 1 0 011.414 0A9.972 9.972 0 0119 10a9.972 9.972 0 01-2.929 7.071 1 1 0 01-1.414-1.414A7.971 7.971 0 0017 10c0-2.21-.894-4.208-2.343-5.657a1 1 0 010-1.414zm-2.829 2.828a1 1 0 011.415 0A5.983 5.983 0 0115 10a5.984 5.984 0 01-1.757 4.243 1 1 0 01-1.415-1.415A3.984 3.984 0 0013 10a3.983 3.983 0 00-1.172-2.828 1 1 0 010-1.415z" clip-rule="evenodd" />
          </svg>
          <input 
            type="range" 
            min="0" 
            max="100" 
            :value="volume"
            @input="setVolume($event.target.value)"
            class="flex-1 h-2 bg-gray-600 rounded-lg appearance-none cursor-pointer slider"
            :disabled="!isConnected"
          >
          <span class="text-xs text-gray-400 w-8">{{ volume }}</span>
        </div>
      </div>

      <!-- Progress Bar -->
      <div class="mt-2">
        <div class="flex items-center justify-between text-xs text-gray-400 mb-1">
          <span>{{ formatTime(currentTime) }}</span>
          <span>{{ formatTime(duration) }}</span>
        </div>
        <div class="w-full bg-gray-600 rounded-full h-2">
          <div 
            class="bg-blue-600 h-2 rounded-full transition-all duration-1000"
            :style="{ width: `${progressPercentage}%` }"
          ></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useMpdStore } from '@/stores/mpd'

const mpdStore = useMpdStore()

// Computed properties
const currentSong = computed(() => mpdStore.currentSong)
const isPlaying = computed(() => mpdStore.isPlaying)
const isConnected = computed(() => mpdStore.isConnected)
const currentTime = computed(() => mpdStore.currentTime)
const duration = computed(() => mpdStore.duration)
const volume = computed(() => mpdStore.volume)

const progressPercentage = computed(() => {
  if (!duration.value) return 0
  return (currentTime.value / duration.value) * 100
})

// Actions
const play = () => mpdStore.play()
const pause = () => mpdStore.pause()
const next = () => mpdStore.next()
const previous = () => mpdStore.previous()
const setVolume = (newVolume) => mpdStore.setVolume(parseInt(newVolume))

// Utility functions
const formatTime = (seconds) => {
  if (!seconds) return '0:00'
  
  const minutes = Math.floor(seconds / 60)
  const remainingSeconds = Math.floor(seconds % 60)
  return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`
}
</script>

<style scoped>
.slider {
  background: linear-gradient(to right, #3b82f6 0%, #3b82f6 var(--value, 0%), #4b5563 var(--value, 0%), #4b5563 100%);
}

.slider::-webkit-slider-thumb {
  appearance: none;
  height: 16px;
  width: 16px;
  border-radius: 50%;
  background: #ffffff;
  cursor: pointer;
  border: 2px solid #3b82f6;
}

.slider::-moz-range-thumb {
  height: 16px;
  width: 16px;
  border-radius: 50%;
  background: #ffffff;
  cursor: pointer;
  border: 2px solid #3b82f6;
}

.slider:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
</style>