import { ref, computed } from 'vue'
import axios from 'axios'

// Simple reactive state
const status = ref(null)
const isConnected = ref(false)
const ws = ref(null)
const connectionError = ref(null)

// API base URL
const API_BASE = '/api'

// Computed properties
const currentSong = computed(() => status.value?.currentSong)
const isPlaying = computed(() => status.value?.state === 'play')
const currentTime = computed(() => status.value?.elapsed || 0)
const duration = computed(() => status.value?.duration || 0)
const volume = computed(() => status.value?.volume || 0)

// Actions
const connect = async () => {
  try {
    // Test connection with status endpoint
    const response = await axios.get(`${API_BASE}/status`)
    status.value = response.data.data
    isConnected.value = true
    
    // Connect WebSocket for real-time updates
    connectWebSocket()
  } catch (error) {
    console.error('Failed to connect to MPD:', error)
    isConnected.value = false
    connectionError.value = error.message
  }
}

// Function to manually refresh status (for explicit user requests)
const refreshStatus = async () => {
  try {
    // Use the new refresh endpoint which will broadcast to all WebSocket clients
    const response = await axios.post(`${API_BASE}/status/refresh`)
    // The status will be updated via WebSocket push
    return response.data
  } catch (error) {
    console.error('Failed to refresh MPD status:', error)
    throw error
  }
}

const connectWebSocket = () => {
  try {
    ws.value = new WebSocket(`ws://${window.location.host}/ws`)
    
    ws.value.onopen = () => {
      console.log('WebSocket connected')
    }
    
    ws.value.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data)
        status.value = data
      } catch (error) {
        console.error('WebSocket message parse error:', error)
      }
    }
    
    ws.value.onclose = () => {
      console.log('WebSocket disconnected')
      // Reconnect after delay
      setTimeout(() => {
        if (isConnected.value) {
          connectWebSocket()
        }
      }, 5000)
    }
    
    ws.value.onerror = (error) => {
      console.error('WebSocket error:', error)
    }
  } catch (error) {
    console.error('Failed to connect WebSocket:', error)
  }
}

// Playback controls
const play = async () => {
  try {
    await axios.post(`${API_BASE}/play`)
    // Status will update via WebSocket
  } catch (error) {
    console.error('Play failed:', error)
  }
}

const pause = async () => {
  try {
    await axios.post(`${API_BASE}/pause`)
    // Status will update via WebSocket
  } catch (error) {
    console.error('Pause failed:', error)
  }
}

const next = async () => {
  try {
    await axios.post(`${API_BASE}/next`)
    // Status will update via WebSocket
  } catch (error) {
    console.error('Next failed:', error)
  }
}

const previous = async () => {
  try {
    await axios.post(`${API_BASE}/previous`)
    // Status will update via WebSocket
  } catch (error) {
    console.error('Previous failed:', error)
  }
}

const setVolume = async (newVolume) => {
  try {
    await axios.post(`${API_BASE}/volume/${newVolume}`)
    // Status will update via WebSocket
  } catch (error) {
    console.error('Set volume failed:', error)
  }
}

// Data fetching
const fetchAlbums = async (page = 1, limit = 50, search = '') => {
  try {
    const params = new URLSearchParams({
      page: page.toString(),
      limit: limit.toString()
    })
    
    if (search) {
      params.append('search', search)
    }

    const response = await axios.get(`${API_BASE}/albums?${params}`)
    return response.data
  } catch (error) {
    console.error('Fetch albums failed:', error)
    throw error
  }
}

const fetchArtists = async (page = 1, limit = 50, search = '') => {
  try {
    const params = new URLSearchParams({
      page: page.toString(),
      limit: limit.toString()
    })
    
    if (search) {
      params.append('search', search)
    }

    const response = await axios.get(`${API_BASE}/artists?${params}`)
    return response.data
  } catch (error) {
    console.error('Fetch artists failed:', error)
    throw error
  }
}

const fetchAlbumsByDate = async (page = 1, limit = 50, search = '') => {
  try {
    const params = new URLSearchParams({
      page: page.toString(),
      limit: limit.toString(),
      sort: 'date'
    })
    
    if (search) {
      params.append('search', search)
    }

    const response = await axios.get(`${API_BASE}/albums?${params}`)
    return response.data
  } catch (error) {
    console.error('Fetch albums by date failed:', error)
    throw error
  }
}

const enhancedSearch = async (query, page = 1, limit = 30) => {
  try {
    const params = new URLSearchParams({
      q: query,
      page: page.toString(),
      limit: limit.toString()
    })

    const response = await axios.get(`${API_BASE}/search/enhanced?${params}`)
    return response.data
  } catch (error) {
    console.error('Enhanced search failed:', error)
    throw error
  }
}

const fetchAlbumSongs = async (artist, album, page = 1, limit = 50) => {
  try {
    const params = new URLSearchParams({
      page: page.toString(),
      limit: limit.toString()
    })

    const response = await axios.get(`${API_BASE}/album/${artist}/${album}?${params}`)
    return response.data
  } catch (error) {
    console.error('Fetch album songs failed:', error)
    throw error
  }
}

const search = async (query, type = 'song', page = 1, limit = 30) => {
  try {
    const params = new URLSearchParams({
      q: query,
      type: type,
      page: page.toString(),
      limit: limit.toString()
    })

    const response = await axios.get(`${API_BASE}/search?${params}`)
    return response.data
  } catch (error) {
    console.error('Search failed:', error)
    throw error
  }
}

const addToPlaylist = async (uri) => {
  try {
    await axios.post(`${API_BASE}/playlist/add/${encodeURIComponent(uri)}`)
  } catch (error) {
    console.error('Add to playlist failed:', error)
    throw error
  }
}

const removeFromPlaylist = async (position) => {
  try {
    await axios.post(`${API_BASE}/playlist/remove/${position}`)
  } catch (error) {
    console.error('Remove from playlist failed:', error)
    throw error
  }
}

const fuzzySearch = async (query) => {
  try {
    const response = await axios.get(`${API_BASE}/search/fuzzy?q=${encodeURIComponent(query)}`)
    return response.data
  } catch (error) {
    console.error('Fuzzy search failed:', error)
    throw error
  }
}

const fetchMetadataCandidates = async (artist, album) => {
  try {
    const response = await axios.get(`${API_BASE}/metadata/search?artist=${encodeURIComponent(artist)}&album=${encodeURIComponent(album)}`)
    return response.data
  } catch (error) {
    console.error('Fetch metadata candidates failed:', error)
    throw error
  }
}

const fetchCoverArtCandidates = async (artist, album) => {
  try {
    const response = await axios.get(`${API_BASE}/coverart/candidates?artist=${encodeURIComponent(artist)}&album=${encodeURIComponent(album)}`)
    return response.data
  } catch (error) {
    console.error('Fetch cover art candidates failed:', error)
    throw error
  }
}

const applyCoverArt = async (albumPath, imageUrl) => {
  try {
    await axios.post(`${API_BASE}/coverart/apply`, { albumPath, imageUrl })
  } catch (error) {
    console.error('Apply cover art failed:', error)
    throw error
  }
}

const getSyncStatus = async () => {
  try {
    const response = await axios.get(`${API_BASE}/sync/status`)
    return response.data
  } catch (error) {
    console.error('Get sync status failed:', error)
    throw error
  }
}

const startSync = async () => {
  try {
    await axios.post(`${API_BASE}/sync/start`)
  } catch (error) {
    console.error('Start sync failed:', error)
    throw error
  }
}

const getConfig = async () => {
  try {
    const response = await axios.get(`${API_BASE}/config`)
    return response.data
  } catch (error) {
    console.error('Get config failed:', error)
    throw error
  }
}

const updateConfig = async (config) => {
  try {
    // Ensure the config object has the correct field names for the backend
    const configToSend = {
      mpdHost: config.mpdHost || config.host || config.MPDHost,
      mpdPort: config.mpdPort || config.port || config.MPDPort,
      mpdPassword: config.mpdPassword || config.password || config.MPDPassword,
      musicRoot: config.musicRoot,
      coverArtRoot: config.coverArtRoot,
      discogsToken: config.discogsToken,
      rsyncRemoteTarget: config.rsyncRemoteTarget,
      rsyncOptions: config.rsyncOptions
    };
    
    const response = await axios.post(`${API_BASE}/config`, configToSend)
    return response.data
  } catch (error) {
    console.error('Update config failed:', error)
    throw error
  }
}

// Cleanup
const disconnect = () => {
  if (ws.value) {
    ws.value.close()
    ws.value = null
  }
  isConnected.value = false
}

// Export the store interface
export function useMpdStore() {
  return {
    // State
    status,
    isConnected,
    connectionError,
    
    // Computed
    currentSong,
    isPlaying,
    currentTime,
    duration,
    volume,
    
    // Actions
    connect,
    disconnect,
    play,
    pause,
    next,
    previous,
    setVolume,
    refreshStatus,
    
    // Data fetching
    fetchAlbums,
    fetchArtists,
    fetchAlbumsByDate,
    enhancedSearch,
    fetchAlbumSongs,
    search,
    fuzzySearch,
    fetchMetadataCandidates,
    fetchCoverArtCandidates,
    applyCoverArt,
    getSyncStatus,
    startSync,
    getConfig,
    updateConfig,
    addToPlaylist,
    removeFromPlaylist
  }
}