<template>
  <div class="space-y-8">
    <h1 class="text-3xl font-bold text-white">Library Management</h1>

    <!-- Fuzzy Search Section -->
    <section class="bg-gray-800 rounded-lg p-6">
      <h2 class="text-xl font-semibold text-white mb-4">Fuzzy Search</h2>
      <div class="flex space-x-4 mb-6">
        <input 
          v-model="searchQuery" 
          @input="handleSearch"
          type="text" 
          placeholder="Search albums, artists, songs..." 
          class="flex-1 bg-gray-700 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
      </div>
      <div v-if="searchResults.length > 0" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <div v-for="album in searchResults" :key="album.id" class="bg-gray-700 p-4 rounded-lg flex items-center space-x-4">
          <div class="w-12 h-12 bg-gray-600 rounded flex items-center justify-center">
            <svg class="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
              <path d="M18 3a1 1 0 00-1.196-.98l-10 2A1 1 0 006 5v9.114A4.369 4.369 0 005 14c-1.657 0-3 .895-3 2s1.343 2 3 2 3-.895 3-2V7.82l8-1.6v5.894A4.369 4.369 0 0015 12c-1.657 0-3 .895-3 2s1.343 2 3 2 3-.895 3-2V3z" />
            </svg>
          </div>
          <div>
            <h3 class="text-white font-medium">{{ album.album }}</h3>
            <p class="text-gray-400 text-sm">{{ album.artist }}</p>
          </div>
        </div>
      </div>
      <p v-else-if="searchQuery.length >= 3" class="text-gray-500">No results found.</p>
    </section>

    <!-- Rsync Sync Section -->
    <section class="bg-gray-800 rounded-lg p-6">
      <h2 class="text-xl font-semibold text-white mb-4">Library Sync (Rsync)</h2>
      <div class="flex items-center justify-between mb-4">
        <div>
          <p class="text-white">Status: 
            <span :class="syncStatus?.isRunning ? 'text-blue-400' : 'text-gray-400'">
              {{ syncStatus?.isRunning ? 'Running' : 'Idle' }}
            </span>
          </p>
          <p v-if="syncStatus?.lastRun" class="text-gray-400 text-sm">
            Last Run: {{ new Date(syncStatus.lastRun).toLocaleString() }} 
            ({{ syncStatus.lastSuccess ? 'Success' : 'Failed' }})
          </p>
        </div>
        <button 
          @click="triggerSync" 
          :disabled="syncStatus?.isRunning"
          class="bg-blue-600 hover:bg-blue-500 disabled:bg-gray-600 text-white px-6 py-2 rounded-lg transition-colors"
        >
          {{ syncStatus?.isRunning ? 'Syncing...' : 'Sync Now' }}
        </button>
      </div>
      <div v-if="syncStatus?.isRunning" class="w-full bg-gray-700 rounded-full h-2.5">
        <div class="bg-blue-600 h-2.5 rounded-full transition-all duration-500" :style="{ width: syncStatus.progress + '%' }"></div>
      </div>
      <p v-if="syncStatus?.lastError" class="text-red-400 text-sm mt-2">{{ syncStatus.lastError }}</p>
    </section>

    <!-- Configuration Section -->
    <section class="bg-gray-800 rounded-lg p-6">
      <h2 class="text-xl font-semibold text-white mb-4">Configuration</h2>
      <form @submit.prevent="saveConfig" class="space-y-4">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label class="block text-gray-400 text-sm mb-1">MPD Host</label>
            <input v-model="config.mpdHost" type="text" class="w-full bg-gray-700 text-white rounded px-3 py-2">
          </div>
          <div>
            <label class="block text-gray-400 text-sm mb-1">MPD Port</label>
            <input v-model.number="config.mpdPort" type="number" class="w-full bg-gray-700 text-white rounded px-3 py-2">
          </div>
          <div>
            <label class="block text-gray-400 text-sm mb-1">Music Root (HDD)</label>
            <input v-model="config.musicRoot" type="text" class="w-full bg-gray-700 text-white rounded px-3 py-2">
          </div>
          <div>
            <label class="block text-gray-400 text-sm mb-1">Cover Art Root (SSD)</label>
            <input v-model="config.coverArtRoot" type="text" class="w-full bg-gray-700 text-white rounded px-3 py-2">
          </div>
          <div>
            <label class="block text-gray-400 text-sm mb-1">Discogs Token</label>
            <input v-model="config.discogsToken" type="password" class="w-full bg-gray-700 text-white rounded px-3 py-2">
          </div>
          <div>
            <label class="block text-gray-400 text-sm mb-1">Rsync Target</label>
            <input v-model="config.rsyncRemoteTarget" type="text" class="w-full bg-gray-700 text-white rounded px-3 py-2" placeholder="user@host:/path">
          </div>
        </div>
        <div class="flex justify-end">
          <button type="submit" class="bg-green-600 hover:bg-green-500 text-white px-6 py-2 rounded-lg transition-colors">
            Save Configuration
          </button>
        </div>
      </form>
    </section>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import { useMpdStore } from '@/stores/mpd'

const mpdStore = useMpdStore()

const searchQuery = ref('')
const searchResults = ref([])
const syncStatus = ref(null)
const config = ref({
  mpdHost: '',
  mpdPort: 6600,
  musicRoot: '',
  coverArtRoot: '',
  discogsToken: '',
  rsyncRemoteTarget: ''
})

let syncInterval = null
let searchTimeout = null

const handleSearch = () => {
  if (searchTimeout) clearTimeout(searchTimeout)
  if (searchQuery.value.length < 3) {
    searchResults.value = []
    return
  }
  
  searchTimeout = setTimeout(async () => {
    const response = await mpdStore.fuzzySearch(searchQuery.value)
    if (response.success) {
      searchResults.value = response.data
    }
  }, 500)
}

const fetchSyncStatus = async () => {
  const response = await mpdStore.getSyncStatus()
  if (response.success) {
    syncStatus.value = response.data
  }
}

const triggerSync = async () => {
  await mpdStore.startSync()
  fetchSyncStatus()
}

const loadConfig = async () => {
  const response = await mpdStore.getConfig()
  if (response.success) {
    config.value = { ...response.data }
  }
}

const saveConfig = async () => {
  const response = await mpdStore.updateConfig(config.value)
  if (response.success) {
    alert('Configuration saved successfully')
  }
}

onMounted(() => {
  loadConfig()
  fetchSyncStatus()
  syncInterval = setInterval(fetchSyncStatus, 2000)
})

onUnmounted(() => {
  if (syncInterval) clearInterval(syncInterval)
  if (searchTimeout) clearTimeout(searchTimeout)
})
</script>
