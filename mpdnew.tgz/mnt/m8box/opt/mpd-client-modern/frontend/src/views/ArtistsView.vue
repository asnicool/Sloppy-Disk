<template>
  <div class="space-y-6">
    <h1 class="text-3xl font-bold text-white">Artists</h1>
    <div v-if="loading" class="text-gray-400">Loading artists...</div>
    <div v-else class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
      <div 
        v-for="artist in artists" 
        :key="artist"
        class="bg-gray-800 p-4 rounded-lg text-center hover:bg-gray-700 transition-colors cursor-pointer"
      >
        <div class="w-16 h-16 bg-gray-700 rounded-full mx-auto mb-3 flex items-center justify-center">
          <svg class="w-8 h-8 text-gray-500" fill="currentColor" viewBox="0 0 20 20">
            <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd" />
          </svg>
        </div>
        <h3 class="text-white font-medium truncate">{{ artist }}</h3>
      </div>
    </div>

    <!-- Pagination Controls -->
    <div v-if="!loading && artists.length > 0" class="flex justify-center items-center space-x-4 mt-6">
      <button 
        @click="prevPage" 
        :disabled="currentPage <= 1"
        class="px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        Previous
      </button>
      <span class="text-white">Page {{ currentPage }} of {{ totalPages }}</span>
      <button 
        @click="nextPage" 
        :disabled="currentPage >= totalPages"
        class="px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        Next
      </button>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useMpdStore } from '@/stores/mpd'

const mpdStore = useMpdStore()
const artists = ref([])
const loading = ref(true)
const currentPage = ref(1)
const totalPages = ref(1)
const totalArtists = ref(0)
const hasMore = ref(false)
const itemsPerPage = 50

const loadArtists = async () => {
  loading.value = true
  try {
    const response = await mpdStore.fetchArtists(currentPage.value, itemsPerPage)
    if (response.success) {
      artists.value = response.data
      // Update pagination metadata
      if (response.meta) {
        totalArtists.value = response.meta.total || 0
        hasMore.value = response.meta.hasMore || false
        // Calculate total pages based on total and limit
        totalPages.value = Math.ceil(totalArtists.value / itemsPerPage)
      } else {
        // Fallback to length-based calculation if no metadata
        totalArtists.value = artists.value.length
        totalPages.value = 1
      }
    }
  } finally {
    loading.value = false
  }
}

const nextPage = async () => {
  if (currentPage.value < totalPages.value) {
    currentPage.value++
    await loadArtists()
  }
}

const prevPage = async () => {
  if (currentPage.value > 1) {
    currentPage.value--
    await loadArtists()
  }
}

onMounted(async () => {
 await loadArtists()
})
</script>
