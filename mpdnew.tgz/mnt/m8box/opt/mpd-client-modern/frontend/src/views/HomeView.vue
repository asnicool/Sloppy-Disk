<template>
  <div class="space-y-8">
    <!-- Welcome Section -->
    <div class="text-center">
      <h1 class="text-3xl font-bold text-white mb-4">Welcome to MPD Client</h1>
      <p class="text-gray-400 text-lg">
        Browse your music collection with this modern, lightweight interface
      </p>
    </div>

    <!-- Quick Actions -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <router-link 
        to="/albums"
        class="bg-gray-800 rounded-lg p-6 hover:bg-gray-700 transition-colors group"
      >
        <div class="flex items-center space-x-4">
          <div class="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center group-hover:bg-blue-500 transition-colors">
            <svg class="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 20 20">
              <path d="M18 3a1 1 0 00-1.196-.98l-10 2A1 1 0 006 5v9.114A4.369 4.369 0 005 14c-1.657 0-3 .895-3 2s1.343 2 3 2 3-.895 3-2V7.82l8-1.6v5.894A4.369 4.369 0 0015 12c-1.657 0-3 .895-3 2s1.343 2 3 2 3-.895 3-2V3z" />
            </svg>
          </div>
          <div>
            <h3 class="text-lg font-semibold text-white">Albums</h3>
            <p class="text-gray-400 text-sm">Browse by albums</p>
          </div>
        </div>
      </router-link>

      <router-link 
        to="/artists"
        class="bg-gray-800 rounded-lg p-6 hover:bg-gray-700 transition-colors group"
      >
        <div class="flex items-center space-x-4">
          <div class="w-12 h-12 bg-green-600 rounded-lg flex items-center justify-center group-hover:bg-green-500 transition-colors">
            <svg class="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 20 20">
              <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd" />
            </svg>
          </div>
          <div>
            <h3 class="text-lg font-semibold text-white">Artists</h3>
            <p class="text-gray-400 text-sm">Browse by artists</p>
          </div>
        </div>
      </router-link>

      <router-link 
        to="/search"
        class="bg-gray-800 rounded-lg p-6 hover:bg-gray-700 transition-colors group"
      >
        <div class="flex items-center space-x-4">
          <div class="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center group-hover:bg-purple-500 transition-colors">
            <svg class="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 20 20">
              <path fill-rule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clip-rule="evenodd" />
            </svg>
          </div>
          <div>
            <h3 class="text-lg font-semibold text-white">Search</h3>
            <p class="text-gray-400 text-sm">Find your music</p>
          </div>
        </div>
      </router-link>

      <div class="bg-gray-800 rounded-lg p-6">
        <div class="flex items-center space-x-4">
          <div class="w-12 h-12 bg-yellow-600 rounded-lg flex items-center justify-center">
            <svg class="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 20 20">
              <path fill-rule="evenodd" d="M11.3 1.046A1 1 0 0112 2v5h4a1 1 0 01.82 1.573l-7 10A1 1 0 018 18v-5H4a1 1 0 01-.82-1.573l7-10a1 1 0 011.12-.38z" clip-rule="evenodd" />
            </svg>
          </div>
          <div>
            <h3 class="text-lg font-semibold text-white">Status</h3>
            <p class="text-gray-400 text-sm">
              {{ connectionStatus }}
            </p>
          </div>
        </div>
      </div>
    </div>

    <!-- Current Status -->
    <div v-if="currentSong" class="bg-gray-800 rounded-lg p-6">
      <h2 class="text-xl font-semibold text-white mb-4">Now Playing</h2>
      <div class="flex items-center space-x-4">
        <div class="w-16 h-16 bg-gray-600 rounded-lg flex items-center justify-center">
          <svg class="w-8 h-8 text-gray-300" fill="currentColor" viewBox="0 0 20 20">
            <path d="M18 3a1 1 0 00-1.196-.98l-10 2A1 1 0 006 5v9.114A4.369 4.369 0 005 14c-1.657 0-3 .895-3 2s1.343 2 3 2 3-.895 3-2V7.82l8-1.6v5.894A4.369 4.369 0 0015 12c-1.657 0-3 .895-3 2s1.343 2 3 2 3-.895 3-2V3z" />
          </svg>
        </div>
        <div class="flex-1">
          <h3 class="text-lg font-medium text-white">{{ currentSong.title }}</h3>
          <p class="text-gray-400">{{ currentSong.artist }}</p>
          <p v-if="currentSong.album" class="text-gray-500 text-sm">{{ currentSong.album }}</p>
        </div>
        <div class="text-right">
          <p class="text-sm text-gray-400">{{ formatDuration(currentSong.duration) }}</p>
        </div>
      </div>
    </div>

    <!-- Recent Activity -->
    <div class="bg-gray-800 rounded-lg p-6">
      <h2 class="text-xl font-semibold text-white mb-4">Quick Stats</h2>
      <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div class="text-center">
          <p class="text-2xl font-bold text-blue-400">{{ status?.playlist || 0 }}</p>
          <p class="text-gray-400 text-sm">In Playlist</p>
        </div>
        <div class="text-center">
          <p class="text-2xl font-bold text-green-400">{{ status?.volume || 0 }}%</p>
          <p class="text-gray-400 text-sm">Volume</p>
        </div>
        <div class="text-center">
          <p class="text-2xl font-bold text-purple-400">
            {{ status?.random ? 'On' : 'Off' }}
          </p>
          <p class="text-gray-400 text-sm">Random</p>
        </div>
        <div class="text-center">
          <p class="text-2xl font-bold text-yellow-400">
            {{ status?.repeat ? 'On' : 'Off' }}
          </p>
          <p class="text-gray-400 text-sm">Repeat</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import { useMpdStore } from '@/stores/mpd'

const mpdStore = useMpdStore()

// Computed properties
const currentSong = computed(() => mpdStore.currentSong)
const status = computed(() => mpdStore.status)
const isConnected = computed(() => mpdStore.isConnected)

const connectionStatus = computed(() => {
  if (isConnected.value) {
    return 'Connected'
  }
  return 'Disconnected'
})

// Utility functions
const formatDuration = (seconds) => {
  if (!seconds) return '0:00'
  
  const minutes = Math.floor(seconds / 60)
  const remainingSeconds = Math.floor(seconds % 60)
  return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`
}
</script>