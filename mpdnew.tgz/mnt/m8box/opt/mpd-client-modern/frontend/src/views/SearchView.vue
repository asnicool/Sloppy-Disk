<template>
  <div class="space-y-6">
    <h1 class="text-3xl font-bold text-white">Search</h1>
    <div class="flex space-x-4">
      <input 
        v-model="query" 
        @keyup.enter="performSearch"
        @input="debouncedSearch"
        type="text" 
        placeholder="Search for songs, albums or artists (min 2 chars)..." 
        class="flex-1 bg-gray-800 text-white rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
      >
      <button @click="performSearch" class="bg-blue-600 hover:bg-blue-50 text-white px-6 py-2 rounded-lg transition-colors">
        Search
      </button>
    </div>

    <div v-if="loading" class="text-gray-400">Searching...</div>
    <div v-else-if="results.length > 0" class="space-y-4">
      <div v-for="result in results" :key="result.path || result.album" class="bg-gray-800 p-4 rounded-lg flex items-center justify-between">
        <div>
          <h3 class="text-white font-medium">{{ result.title || result.album }}</h3>
          <p class="text-gray-400 text-sm">{{ result.artist }}</p>
        </div>
        <button v-if="result.path" @click="playTrack(result)" class="text-blue-400 hover:text-blue-300">Play</button>
      </div>
    </div>
    <div v-else-if="searched && query.length >= 2" class="text-gray-500 text-center py-12">
      No results found for "{{ query }}"
    </div>
    <div v-else-if="searched && query.length < 2" class="text-gray-500 text-center py-12">
      Please enter at least 2 characters to search
    </div>

    <!-- Pagination Controls -->
    <div v-if="!loading && results.length > 0" class="flex justify-center items-center space-x-4 mt-6">
      <button 
        @click="prevPage" 
        :disabled="currentPage <= 1"
        class="px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        Previous
      </button>
      <span class="text-white">Page {{ currentPage }} of {{ totalPages }}</span>
      <button 
        @click="nextPage" 
        :disabled="currentPage >= totalPages"
        class="px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        Next
      </button>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useMpdStore } from '@/stores/mpd'
import { debounce } from 'lodash-es'

const mpdStore = useMpdStore()
const query = ref('')
const results = ref([])
const loading = ref(false)
const searched = ref(false)
const currentPage = ref(1)
const totalPages = ref(1)
const totalResults = ref(0)
const hasMore = ref(false)
const itemsPerPage = 30
let searchTimeout = null

const performSearch = async () => {
  if (query.value.length < 2) {
    results.value = []
    searched.value = true
    return
  }

  loading.value = true
  searched.value = true
  try {
    const response = await mpdStore.enhancedSearch(query.value, currentPage.value, itemsPerPage)
    if (response.success) {
      results.value = response.data
      // Update pagination metadata
      if (response.meta) {
        totalResults.value = response.meta.total || 0
        hasMore.value = response.meta.hasMore || false
        // Calculate total pages based on total and limit
        totalPages.value = Math.ceil(totalResults.value / itemsPerPage)
      } else {
        // Fallback to length-based calculation if no metadata
        totalResults.value = results.value.length
        totalPages.value = 1
      }
    }
  } finally {
    loading.value = false
  }
}

const debouncedSearch = debounce(() => {
  if (query.value.length >= 2) {
    currentPage.value = 1
    performSearch()
  } else {
    results.value = []
  }
}, 500)

const nextPage = async () => {
  if (currentPage.value < totalPages.value) {
    currentPage.value++
    await performSearch()
  }
}

const prevPage = async () => {
  if (currentPage.value > 1) {
    currentPage.value--
    await performSearch()
  }
}

const playTrack = (track) => {
  mpdStore.addToPlaylist(track.path)
}
</script>
