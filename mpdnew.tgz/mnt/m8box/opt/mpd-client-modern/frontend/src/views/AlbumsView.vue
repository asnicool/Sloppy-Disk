<template>
  <div class="space-y-6">
    <h1 class="text-3xl font-bold text-white">Albums</h1>
    <div class="flex justify-between items-center">
      <div class="flex space-x-2">
        <button 
          @click="sortByDate = false" 
          :class="{ 'bg-blue-600': !sortByDate, 'bg-gray-700': sortByDate }"
          class="px-4 py-2 rounded-lg text-white"
        >
          Sort by Name
        </button>
        <button 
          @click="sortByDate = true" 
          :class="{ 'bg-blue-600': sortByDate, 'bg-gray-700': !sortByDate }"
          class="px-4 py-2 rounded-lg text-white"
        >
          Sort by Date
        </button>
      </div>
    </div>
    <div v-if="loading" class="text-gray-400">Loading albums...</div>
    <div v-else class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
      <router-link 
        v-for="album in albums" 
        :key="album.album + album.artist"
        :to="{ name: 'album-detail', params: { artist: album.artist || 'Unknown', album: album.album } }"
        class="bg-gray-800 rounded-lg overflow-hidden hover:bg-gray-700 transition-colors group"
      >
        <div class="aspect-square bg-gray-700 flex items-center justify-center relative">
          <svg class="w-12 h-12 text-gray-600" fill="currentColor" viewBox="0 0 20 20">
            <path d="M18 3a1 0 00-1.196-.98l-10 2A1 1 0 006 5v9.114A4.369 4.369 0 005 14c-1.657 0-3 .895-3 2s1.343 2 3 2 3-.895 3-2V7.82l8-1.6v5.894A4.369 4.369 0 0015 12c-1.657 0-3 .895-3 2s1.343 2 3 2 3-.895 3-2V3z" />
          </svg>
        </div>
        <div class="p-4">
          <h3 class="text-white font-medium truncate">{{ album.album }}</h3>
          <p class="text-gray-400 text-sm truncate">{{ album.artist || 'Various Artists' }}</p>
          <p v-if="album.date" class="text-gray-500 text-xs mt-1">{{ album.date }}</p>
        </div>
      </router-link>
    </div>

    <!-- Pagination Controls -->
    <div v-if="!loading && albums.length > 0" class="flex justify-center items-center space-x-4 mt-6">
      <button 
        @click="prevPage" 
        :disabled="currentPage <= 1"
        class="px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        Previous
      </button>
      <span class="text-white">Page {{ currentPage }} of {{ totalPages }}</span>
      <button 
        @click="nextPage" 
        :disabled="currentPage >= totalPages"
        class="px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        Next
      </button>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue'
import { useMpdStore } from '@/stores/mpd'

const mpdStore = useMpdStore()
const albums = ref([])
const loading = ref(true)
const currentPage = ref(1)
const totalPages = ref(1)
const totalAlbums = ref(0)
const hasMore = ref(false)
const itemsPerPage = 50
const sortByDate = ref(false)

const loadAlbums = async () => {
  loading.value = true
  try {
    if (sortByDate.value) {
      const response = await mpdStore.fetchAlbumsByDate(currentPage.value, itemsPerPage)
      if (response.success) {
        albums.value = response.data
        // Update pagination metadata
        if (response.meta) {
          totalAlbums.value = response.meta.total || 0
          hasMore.value = response.meta.hasMore || false
          // Calculate total pages based on total and limit
          totalPages.value = Math.ceil(totalAlbums.value / itemsPerPage)
        } else {
          // Fallback to length-based calculation if no metadata
          totalAlbums.value = albums.value.length
          totalPages.value = 1
        }
      }
    } else {
      const response = await mpdStore.fetchAlbums(currentPage.value, itemsPerPage)
      if (response.success) {
        albums.value = response.data
        // Update pagination metadata
        if (response.meta) {
          totalAlbums.value = response.meta.total || 0
          hasMore.value = response.meta.hasMore || false
          // Calculate total pages based on total and limit
          totalPages.value = Math.ceil(totalAlbums.value / itemsPerPage)
        } else {
          // Fallback to length-based calculation if no metadata
          totalAlbums.value = albums.value.length
          totalPages.value = 1
        }
      }
    }
  } finally {
    loading.value = false
  }
}

const nextPage = async () => {
  if (currentPage.value < totalPages.value) {
    currentPage.value++
    await loadAlbums()
  }
}

const prevPage = async () => {
  if (currentPage.value > 1) {
    currentPage.value--
    await loadAlbums()
  }
}

// Watch for changes in sortByDate and reset to page 1
watch(sortByDate, async () => {
  currentPage.value = 1
  await loadAlbums()
})

onMounted(async () => {
  await loadAlbums()
})
</script>
