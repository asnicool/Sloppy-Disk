<template>
  <div id="app" class="min-h-screen bg-gray-900 text-white">
    <!-- Navigation Header -->
    <nav class="bg-gray-800 border-b border-gray-700">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between h-16">
          <div class="flex items-center">
            <h1 class="text-xl font-bold text-blue-400">MPD Client</h1>
          </div>

          <div class="hidden md:flex items-center space-x-8">
            <router-link to="/" class="text-gray-300 hover:text-white transition-colors">Home</router-link>
            <router-link to="/albums" class="text-gray-300 hover:text-white transition-colors">Albums</router-link>
            <router-link to="/artists" class="text-gray-300 hover:text-white transition-colors">Artists</router-link>
            <router-link to="/library" class="text-gray-300 hover:text-white transition-colors">Library</router-link>
          </div>
          
          <div class="flex items-center space-x-4">
            <!-- Connection Status -->
            <div class="flex items-center space-x-2">
              <div 
                :class="[
                  'w-3 h-3 rounded-full',
                  isConnected ? 'bg-green-400' : 'bg-red-400'
                ]"
              ></div>
              <span class="text-sm text-gray-300">
                {{ isConnected ? 'Connected' : 'Disconnected' }}
              </span>
            </div>
          </div>
        </div>
      </div>
    </nav>

    <!-- Main Content -->
    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <router-view />
    </main>

    <!-- Player Controls (Fixed Bottom) -->
    <PlayerControls v-if="currentSong" class="fixed bottom-0 left-0 right-0" />
  </div>
</template>

<script setup>
import { computed, onMounted } from 'vue'
import { useMpdStore } from '@/stores/mpd'
import PlayerControls from '@/components/PlayerControls.vue'

const mpdStore = useMpdStore()

const isConnected = computed(() => mpdStore.isConnected)
const currentSong = computed(() => mpdStore.status?.currentSong)

onMounted(() => {
  // Initialize MPD connection
  mpdStore.connect()
})
</script>

<style>
/* Global styles */
#app {
  font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}

/* Custom scrollbar */
::-webkit-scrollbar {
  width: 6px;
}

::-webkit-scrollbar-track {
  background: #1f2937;
}

::-webkit-scrollbar-thumb {
  background: #4b5563;
  border-radius: 3px;
}

::-webkit-scrollbar-thumb:hover {
  background: #6b7280;
}

/* Touch-friendly sizing */
button, .clickable {
  min-height: 44px;
  min-width: 44px;
}

/* Loading animations */
@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}

.animate-pulse {
  animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
}
</style>