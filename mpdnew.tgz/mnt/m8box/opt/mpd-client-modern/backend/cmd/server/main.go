package main

import (
    "context"
    "fmt"
    "io"
    "log"
    "net/http"
    "os"
    "os/signal"
    "path/filepath"
    "syscall"
    "time"

    "mpd-client-modern/internal/api"
    "mpd-client-modern/internal/config"
    "mpd-client-modern/internal/mpd"
    "mpd-client-modern/internal/models"
    "github.com/gorilla/mux"
)

func main() {
	// 1. Load Configuration
	if err := config.Load(); err!= nil {
		log.Fatalf("Failed to load config: %v", err)
	}
	
	// Set up the MPD connection status callback to broadcast to WebSocket clients
	mpd.SetConnectionStatusCallback(func(status *models.MPDStatus) {
		if api.GlobalBroadcaster != nil {
			api.GlobalBroadcaster.Broadcast(status)
		}
	})

	// 2. Setup Router
	r := mux.NewRouter()

	// CORS middleware
	r.Use(func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("Access-Control-Allow-Origin", "*")
			w.Header().Set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
			w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")
			if r.Method == "OPTIONS" {
				w.WriteHeader(http.StatusOK)
				return
			}
			next.ServeHTTP(w, r)
		})
	})

	// 3. Register Routes
	api.RegisterRoutes(r)

	// Static file serving for frontend
	// Use absolute paths to avoid issues with working directory
	baseDir := "/mnt/m8box/opt/mpd-client-modern"
	frontendDir := filepath.Join(baseDir, "frontend")

	// Serve simple.html for the root and /simple.html as in the original
	r.HandleFunc("/simple.html", serveFrontendFile(filepath.Join(frontendDir, "simple.html"))).Methods("GET")
	r.HandleFunc("/", serveFrontendFile(filepath.Join(frontendDir, "simple.html"))).Methods("GET")

	// Serve other static files from frontend directory
	r.PathPrefix("/").Handler(http.FileServer(http.Dir(frontendDir)))

	// 4. Start Server
	port := os.Getenv("PORT")
	if port == "" {
		port = "8080"
	}

	srv := &http.Server{
		Addr:         ":" + port,
		Handler:      r,
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 15 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	go func() {
		fmt.Printf("Backend starting on port %s\n", port)
		if err := srv.ListenAndServe(); err!= nil && err!= http.ErrServerClosed {
			log.Fatalf("listen: %s\n", err)
		}
	}()

	// 5. Graceful Shutdown
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit
	log.Println("Shutting down server...")

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := srv.Shutdown(ctx); err!= nil {
		log.Fatal("Server forced to shutdown:", err)
	}
}

func serveFrontendFile(path string) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		// Try to find the file relative to the workspace root
		absPath, err := filepath.Abs(path)
		if err!= nil {
			http.Error(w, "Internal Server Error", http.StatusInternalServerError)
			return
		}

		file, err := os.Open(absPath)
		if err!= nil {
			// Fallback to simple.html if index.html is missing
			if path == "frontend/index.html" {
				serveFrontendFile("frontend/simple.html")(w, r)
				return
			}
			http.Error(w, fmt.Sprintf("Frontend file not found: %v", err), http.StatusNotFound)
			return
		}
		defer file.Close()

		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		io.Copy(w, file)
	}
}
