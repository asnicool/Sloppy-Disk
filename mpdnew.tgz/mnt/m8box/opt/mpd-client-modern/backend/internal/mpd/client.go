package mpd

import (
	"bufio"
	"context"
	"fmt"
	"log"
	"net"
	"strings"
	"sync"
	"time"
	"path/filepath"

	"mpd-client-modern/internal/config"
	"mpd-client-modern/internal/models"
)

type Client struct {
	mu       sync.Mutex
	conn     net.Conn
	reader   *bufio.Reader
	writer   *bufio.Writer
	lastUsed time.Time
	isConnected bool
	configVersion int64 // Track config changes to detect when to reconnect
	isIdleClient bool // Flag to indicate if this client is used for IDLE operations
	idleTimeout time.Duration // Timeout for idle connections, if needed
}

var (
	defaultClient *Client
	idleClient    *Client  // Separate client for IDLE operations
	once          sync.Once
	idleOnce      sync.Once
)

// Create a new client instance for separate connections
func NewClient() *Client {
	return &Client{}
}

// NewIdleClient creates a new client specifically for IDLE operations
func NewIdleClient() *Client {
	return &Client{
		isIdleClient: true,
		idleTimeout: 24 * time.Hour, // 24-hour timeout for idle connections, effectively no timeout
	}
}

func GetClient() *Client {
	once.Do(func() {
		defaultClient = &Client{}
	})
	return defaultClient
}

func (c *Client) EnsureConnection() error {
	c.mu.Lock()
	defer c.mu.Unlock()

	if c.conn != nil {
		// Check if connection is still alive
		c.conn.SetReadDeadline(time.Now().Add(10 * time.Millisecond))
		one := make([]byte, 1)
		if _, err := c.conn.Read(one); err != nil {
			if netErr, ok := err.(net.Error); ok && netErr.Timeout() {
				// Still alive
				c.conn.SetReadDeadline(time.Time{})
			} else {
				c.conn.Close()
				c.conn = nil
				c.isConnected = false
			}
	} else {
			// Should not happen if we are just checking
			c.conn.SetReadDeadline(time.Time{})
		}
	}

	if c.conn == nil {
		cfg := config.Get()
		addr := fmt.Sprintf("%s:%d", cfg.MPDHost, cfg.MPDPort)
	conn, err := net.DialTimeout("tcp", addr, 5*time.Second)
		if err != nil {
			// Only broadcast connection failure if we were previously connected
			if c.isConnected {
				c.isConnected = false
				c.broadcastConnectionStatus(false)
			}
			return fmt.Errorf("failed to connect to MPD: %w", err)
		}

		c.conn = conn
		c.reader = bufio.NewReaderSize(conn, 64*1024) // 64KB buffer to handle large responses
		c.writer = bufio.NewWriterSize(conn, 16*1024) // 16KB write buffer
	c.lastUsed = time.Now()
		c.isConnected = true

		// Set read/write timeouts to prevent hanging
		c.conn.SetDeadline(time.Now().Add(10 * time.Second))

		// Set timeout for reading greeting
	c.conn.SetReadDeadline(time.Now().Add(10 * time.Second))
		line, err := c.reader.ReadString('\n')
		if err != nil {
			c.conn.Close()
			c.conn = nil
			c.isConnected = false
			return fmt.Errorf("failed to read MPD greeting: %w", err)
		}
		// Reset deadline after successful greeting
		c.conn.SetReadDeadline(time.Time{})
		if !strings.HasPrefix(line, "OK MPD") {
			c.conn.Close()
			c.conn = nil
			c.isConnected = false
			return fmt.Errorf("unexpected MPD greeting: %s", line)
		}

		// Authenticate if password is set
		if cfg.MPDPassword != "" {
			if _, err := c.sendCommandLocked(fmt.Sprintf("password %s", cfg.MPDPassword)); err != nil {
				c.conn.Close()
				c.conn = nil
				c.isConnected = false
				return fmt.Errorf("MPD authentication failed: %w", err)
			}
		}
		
		// Broadcast successful connection
		c.broadcastConnectionStatus(true)
	}

	return nil
}

// SetConnectionStatusCallback allows setting a callback function to broadcast connection status
// This helps avoid circular import between mpd and api packages
var connectionStatusCallback func(*models.MPDStatus)

func SetConnectionStatusCallback(callback func(*models.MPDStatus)) {
	connectionStatusCallback = callback
}

// broadcastConnectionStatus sends the connection status to all WebSocket clients via callback
func (c *Client) broadcastConnectionStatus(connected bool) {
	// Create a minimal status with connection info to avoid hanging on full status retrieval
	status := &models.MPDStatus{
		State: "disconnected",
	}
	
	if connected {
		// Only set state to connected if we know we're connected
		status.State = "connected"
	}
	
	if connectionStatusCallback != nil {
		connectionStatusCallback(status)
	}
}

func (c *Client) SendCommand(command string) (string, error) {
	if err := c.EnsureConnection(); err != nil {
		return "", err
	}

	c.mu.Lock()
	defer c.mu.Unlock()

	return c.sendCommandLocked(command)
}

func (c *Client) sendCommandLocked(command string) (string, error) {
	// Ensure connection is still valid before sending command
	if c.conn == nil {
		return "", fmt.Errorf("no connection available")
	}
	
	if _, err := c.writer.WriteString(command + "\n"); err != nil {
	c.conn.Close()
	c.conn = nil
		return "", fmt.Errorf("write error: %w", err)
	}
	if err := c.writer.Flush(); err != nil {
		c.conn.Close()
		c.conn = nil
		return "", fmt.Errorf("flush error: %w", err)
	}

	var response strings.Builder
	for {
		// Set read timeout to prevent hanging
		c.conn.SetReadDeadline(time.Now().Add(10 * time.Second))
		line, err := c.reader.ReadString('\n')
		if err != nil {
			c.conn.Close()
			c.conn = nil
			return response.String(), fmt.Errorf("read error: %w", err)
		}

		if line == "OK\n" {
			break
		}
		if strings.HasPrefix(line, "ACK") {
			c.conn.Close()
			c.conn = nil
			return response.String(), fmt.Errorf("MPD error: %s", strings.TrimSpace(line))
		}
		response.WriteString(line)
	}

	c.lastUsed = time.Now()
	return response.String(), nil
}

// Path Mapping
func (c *Client) ToAbsolutePath(relativePath string) string {
	cfg := config.Get()
	return filepath.Join(cfg.MusicRoot, relativePath)
}

func (c *Client) ToRelativePath(absolutePath string) (string, error) {
	cfg := config.Get()
	rel, err := filepath.Rel(cfg.MusicRoot, absolutePath)
	if err != nil {
		return "", err
	}
	return rel, nil
}

// High-level Domain Methods
func (c *Client) GetStatus() (*models.MPDStatus, error) {
	// Use a context with timeout to prevent hanging
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	done := make(chan struct{})
	var status *models.MPDStatus
	var err error

	go func() {
		defer close(done)
	resp, cmdErr := c.SendCommand("status")
		if cmdErr != nil {
			err = cmdErr
			return
		}
		attrs := ParseResponse(resp)

		songResp, cmdErr := c.SendCommand("currentsong")
	if cmdErr != nil {
			err = cmdErr
			return
		}
		songAttrs := ParseResponse(songResp)

		status = &models.MPDStatus{
			State:    attrs["state"],
			Elapsed: parseFloat(attrs["elapsed"]),
			Duration: parseFloat(attrs["duration"]),
			Volume:   parseInt(attrs["volume"]),
			Random:   attrs["random"] == "1",
			Repeat:   attrs["repeat"] == "1",
			Single:   attrs["single"] == "1",
			Consume:  attrs["consume"] == "1",
			Playlist: parseInt(attrs["playlist"]),
			PlaylistPos: parseInt(attrs["song"]),
			CurrentSong: models.Song{
				Title:    songAttrs["Title"],
				Artist:   songAttrs["Artist"],
				Album:    songAttrs["Album"],
				Track:    songAttrs["Track"],
				Date:     songAttrs["Date"],
				Genre:    songAttrs["Genre"],
				Duration: parseInt(songAttrs["duration"]),
				Path:     songAttrs["file"],
			},
		}
	}()

	select {
	case <-done:
		return status, err
	case <-ctx.Done():
	return nil, fmt.Errorf("GetStatus timed out: %w", ctx.Err())
	}
}

func (c *Client) UpdateDB(path string) error {
	cmd := "update"
	if path != "" {
		cmd = fmt.Sprintf("update \"%s\"", strings.ReplaceAll(path, "\"", "\\\""))
	}
	_, err := c.SendCommand(cmd)
	return err
}

// Utils
func ParseResponse(response string) map[string]string {
	attrs := make(map[string]string)
	lines := strings.Split(strings.TrimSpace(response), "\n")
	for _, line := range lines {
		parts := strings.SplitN(line, ": ", 2)
		if len(parts) == 2 {
			attrs[parts[0]] = parts[1]
		}
	}
	return attrs
}

func parseInt(s string) int {
	var i int
	fmt.Sscanf(s, "%d", &i)
	return i
}

func parseFloat(s string) float64 {
	var f float64
	fmt.Sscanf(s, "%f", &f)
	return f
}

// Idle waits for MPD to notify about changes
// Returns the list of changed subsystems or an error
func (c *Client) Idle(subsystems ...string) ([]string, error) {
	if err := c.EnsureConnection(); err != nil {
		return nil, err
	}

	c.mu.Lock()
	defer c.mu.Unlock()

	// Build the idle command
	cmd := "idle"
	if len(subsystems) > 0 {
		cmd += " " + strings.Join(subsystems, " ")
	}

	if _, err := c.writer.WriteString(cmd + "\n"); err != nil {
		return nil, err
	}
	if err := c.writer.Flush(); err != nil {
		return nil, err
	}

	var changedSubsystems []string
	for {
		// For idle connections, we don't want a timeout since idle is meant to wait indefinitely
		// Only set a timeout if this is not an idle client or if an idle timeout is configured
		if !c.isIdleClient || c.idleTimeout > 0 {
			timeout := c.idleTimeout
			if timeout == 0 {
				timeout = 30 * time.Second // fallback timeout if not specified
			}
			c.conn.SetReadDeadline(time.Now().Add(timeout))
	} else {
			// No timeout for dedicated idle connections
			c.conn.SetReadDeadline(time.Time{})
		}
		line, err := c.reader.ReadString('\n')
		if err != nil {
			c.conn.Close()
			c.conn = nil
			c.isConnected = false
			return nil, err
		}

		line = strings.TrimSpace(line)
		
		// Check for changed subsystem notifications ("changed: <subsystem>")
		if strings.HasPrefix(line, "changed: ") {
			subsystem := strings.TrimSpace(strings.TrimPrefix(line, "changed: "))
			changedSubsystems = append(changedSubsystems, subsystem)
		} else if line == "OK" {
			// End of idle response
			break
		} else if strings.HasPrefix(line, "ACK") {
			return changedSubsystems, fmt.Errorf("MPD error: %s", strings.TrimSpace(line))
		}
		
	}

	return changedSubsystems, nil
}

// IsConnected returns whether the client is currently connected to the MPD server
func (c *Client) IsConnected() bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.isConnected
}

// NoIdle exits idle mode and returns to normal command mode
func (c *Client) NoIdle() (string, error) {
	// Ensure connection is valid first
	if err := c.EnsureConnection(); err != nil {
		return "", fmt.Errorf("failed to establish connection for noidle: %w", err)
	}
	
	c.mu.Lock()
	defer c.mu.Unlock()
	
	// Reset deadline since we're returning to normal command mode
	c.conn.SetReadDeadline(time.Time{})
	
	// Send the noidle command
	if _, err := c.writer.WriteString("noidle\n"); err != nil {
	// If write fails, close the connection so it will be re-established on next use
		c.conn.Close()
		c.conn = nil
		c.isConnected = false
		return "", fmt.Errorf("write error during noidle: %w", err)
	}
	
	if err := c.writer.Flush(); err != nil {
		// If flush fails, close the connection so it will be re-established on next use
		c.conn.Close()
	c.conn = nil
		c.isConnected = false
		return "", fmt.Errorf("flush error during noidle: %w", err)
	}
	
	// Now read the response
	var response strings.Builder
	for {
		line, err := c.reader.ReadString('\n')
		if err != nil {
			// If read fails, close the connection so it will be re-established on next use
			c.conn.Close()
			c.conn = nil
			c.isConnected = false
			return "", fmt.Errorf("read error during noidle: %w", err)
		}
		
		if line == "OK\n" {
			break
		}
		if strings.HasPrefix(line, "ACK") {
			return response.String(), fmt.Errorf("MPD error during noidle: %s", strings.TrimSpace(line))
		}
		response.WriteString(line)
	}
	
	return response.String(), nil
}

// ResetClient resets the MPD client connection to force reconnection with new settings
func ResetClient() {
	defaultClient.mu.Lock()
	if defaultClient.conn != nil {
		defaultClient.conn.Close()
		defaultClient.conn = nil
		defaultClient.isConnected = false
	}
	defaultClient.mu.Unlock()
	
	// Start a background reconnection attempt
	go defaultClient.attemptReconnection()
}

// attemptReconnection tries to connect to the MPD server with exponential backoff
func (c *Client) attemptReconnection() {
	maxRetries := 10
	baseDelay := time.Second
	
	for i := 0; i < maxRetries; i++ {
		// Check if we're already connected
		c.mu.Lock()
		alreadyConnected := c.conn != nil
		c.mu.Unlock()
		
		if alreadyConnected {
			break
		}
		
		// Try to establish connection
		err := c.EnsureConnection()
		if err == nil {
			log.Printf("Successfully reconnected to MPD server")
			break
		}
		
		log.Printf("Failed to connect to MPD server (attempt %d/%d): %v", i+1, maxRetries, err)
		
		// Calculate delay with exponential backoff (with jitter to prevent thundering herd)
		delay := time.Duration(i+1) * baseDelay
		if delay > 30*time.Second {
			delay = 30 * time.Second
		}
		
		// Add some jitter (up to 1 second) to prevent synchronized retries
		jitter := time.Duration((time.Now().UnixNano() % 100000000) % 10000000)
		time.Sleep(delay + (jitter % time.Second))
	}
}

// There's a duplicate method, so I'll remove this one

// ResetConnection closes the current connection to allow reconnection
func (c *Client) ResetConnection() {
	c.mu.Lock()
	defer c.mu.Unlock()
	
	if c.conn != nil {
		c.conn.Close()
		c.conn = nil
		c.isConnected = false
	}
}
