package mpd

import (
	"testing"

	"mpd-client-modern/internal/config"
)

func TestPathMapping(t *testing.T) {
	cfg := &config.Config{
		MusicRoot: "/mnt/music",
	}
	config.Save(cfg)

	client := GetClient()

	rel := "Pink Floyd/Dark Side of the Moon/01. Speak to Me.mp3"
	abs := client.ToAbsolutePath(rel)
	expectedAbs := "/mnt/music/Pink Floyd/Dark Side of the Moon/01. Speak to Me.mp3"

	if abs != expectedAbs {
		t.Errorf("Expected absolute path %s, got %s", expectedAbs, abs)
	}

	relBack, err := client.ToRelativePath(abs)
	if err != nil {
		t.Errorf("Failed to map back to relative path: %v", err)
	}
	if relBack != rel {
		t.Errorf("Expected relative path %s, got %s", rel, relBack)
	}
}

func TestParseResponse(t *testing.T) {
	resp := "Artist: Pink Floyd\nAlbum: Dark Side of the Moon\nTitle: Speak to Me\nOK\n"
	attrs := ParseResponse(resp)

	if attrs["Artist"] != "Pink Floyd" {
		t.Errorf("Expected Artist Pink Floyd, got %s", attrs["Artist"])
	}
	if attrs["Album"] != "Dark Side of the Moon" {
		t.Errorf("Expected Album Dark Side of the Moon, got %s", attrs["Album"])
	}
}
