package models

import "time"

// Album represents an album in MPD database
type Album struct {
	ID          string `json:"id"`
	Album       string `json:"album"`
	Artist      string `json:"artist"`
	Title       string `json:"title"`
	Date        string `json:"date,omitempty"`
	Genre       string `json:"genre,omitempty"`
	TrackCount  int    `json:"trackCount"`
	Duration    int    `json:"duration"` // in seconds
	Path        string `json:"path"`
	CoverURL    string `json:"coverUrl,omitempty"`
}

// Song represents a song with metadata
type Song struct {
	Title     string `json:"title"`
	Artist    string `json:"artist"`
	Album     string `json:"album"`
	Track     string `json:"track,omitempty"`
	Disc      string `json:"disc,omitempty"`
	Date      string `json:"date,omitempty"`
	Genre     string `json:"genre,omitempty"`
	Duration  int    `json:"duration"`
	Path      string `json:"path"`
	Pos       int    `json:"pos,omitempty"` // Position in playlist
}

// MPDStatus represents current MPD playback status
type MPDStatus struct {
	State       string  `json:"state"`        // play, pause, stop
	CurrentSong Song    `json:"currentSong"`
	Elapsed     float64 `json:"elapsed"`      // seconds
	Duration    float64 `json:"duration"`     // seconds
	Volume      int     `json:"volume"`       // 0-100
	Random      bool    `json:"random"`
	Repeat      bool    `json:"repeat"`
	Single      bool    `json:"single"`
	Consume     bool    `json:"consume"`
	Playlist    int     `json:"playlist"`     // playlist length
	PlaylistPos int     `json:"playlistPos"`  // current position
}

// MetadataCandidate represents a metadata record from external sources
type MetadataCandidate struct {
	Source     string `json:"source"`
	Artist     string `json:"artist"`
	Album      string `json:"album"`
	Year       string `json:"year,omitempty"`
	Genre      string `json:"genre,omitempty"`
	Tracks     []Song `json:"tracks,omitempty"`
	ExternalID string `json:"externalId,omitempty"`
}

// CoverArtCandidate represents a cover art image from external sources
type CoverArtCandidate struct {
	Source   string `json:"source"`
	URL      string `json:"url"`
	Thumbnail string `json:"thumbnail,omitempty"`
	Width    int    `json:"width,omitempty"`
	Height   int    `json:"height,omitempty"`
	Size     string `json:"size,omitempty"`
}

// SyncStatus represents the status of rsync synchronization
type SyncStatus struct {
	IsRunning   bool      `json:"isRunning"`
	LastRun     time.Time `json:"lastRun"`
	LastSuccess bool      `json:"lastSuccess"`
	LastError   string    `json:"lastError,omitempty"`
	Progress    float64   `json:"progress"`
}

// APIResponse is the standard API response structure
type APIResponse struct {
	Success bool        `json:"success"`
	Data    interface{} `json:"data,omitempty"`
	Error   string      `json:"error,omitempty"`
	Meta    interface{} `json:"meta,omitempty"`
}

// PaginationMeta defines pagination limits for MPD queries
type PaginationMeta struct {
	Page     int  `json:"page"`
	Limit    int  `json:"limit"`
	Total    int  `json:"total"`
	HasMore  bool `json:"hasMore"`
	NextPage *int `json:"nextPage,omitempty"`
	PrevPage *int `json:"prevPage,omitempty"`
}
