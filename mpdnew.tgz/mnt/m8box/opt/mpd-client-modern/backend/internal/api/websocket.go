package api

import (
	"context"
	"log"
	"net/http"
	"sync"
	"time"

	"mpd-client-modern/internal/mpd"
	"mpd-client-modern/internal/models"
	"github.com/gorilla/websocket"
)

type ClientConnection struct {
	conn *websocket.Conn
	send chan *models.MPDStatus
}

type Broadcaster struct {
	clients    map[*ClientConnection]bool
	register   chan *ClientConnection
	unregister chan *ClientConnection
	broadcast  chan *models.MPDStatus
	mpdClient *mpd.Client
	idleMpdClient *mpd.Client  // Separate client for IDLE operations to avoid blocking
	idleClientConnected bool   // Track if idle client is connected
	ctx        context.Context
	cancel     context.CancelFunc
	mu         sync.RWMutex
}

func NewBroadcaster() *Broadcaster {
	ctx, cancel := context.WithCancel(context.Background())
	
	// Create a separate MPD client instance for IDLE operations
	idleClient := mpd.NewIdleClient()
	
	return &Broadcaster{
		clients:    make(map[*ClientConnection]bool),
		register:   make(chan *ClientConnection),
		unregister: make(chan *ClientConnection),
		broadcast: make(chan *models.MPDStatus, 100), // Buffered channel to prevent blocking
		mpdClient: mpd.GetClient(),
		idleMpdClient: idleClient,
		idleClientConnected: false,
		ctx:        ctx,
		cancel:     cancel,
	}
}

func (b *Broadcaster) Run() {
	go b.listenForMPDChanges()
	
	for {
		select {
		case client := <-b.register:
			b.mu.Lock()
			b.clients[client] = true
			b.mu.Unlock()
			
			// Send current status to the newly connected client
			if status, err := b.mpdClient.GetStatus(); err == nil {
				select {
				case client.send <- status:
				default:
					close(client.send)
					delete(b.clients, client)
				}
			}
			
		case client := <-b.unregister:
			b.mu.Lock()
			if _, ok := b.clients[client]; ok {
				close(client.send)
				delete(b.clients, client)
			}
			b.mu.Unlock()
			
		case status := <-b.broadcast:
			b.mu.RLock()
			for client := range b.clients {
				select {
				case client.send <- status:
				default:
					close(client.send)
					delete(b.clients, client)
				}
			}
			b.mu.RUnlock()
			
		case <-b.ctx.Done():
			return
		}
	}
}

func (b *Broadcaster) listenForMPDChanges() {
	ticker := time.NewTicker(60 * time.Second) // 60-second polling as backup
	defer ticker.Stop()
	
	// Initialize idle client connection
	b.ensureIdleClientConnection()
	
	for {
		select {
		case <-b.ctx.Done():
			return
		default:
			// Use MPD idle command to wait for changes - use the dedicated idle client
			changedSubsystems, err := b.idleMpdClient.Idle()
			if err != nil {
				log.Printf("Error in MPD idle: %v", err)
				// Mark idle client as disconnected
				b.idleClientConnected = false
				// Attempt to reconnect with exponential backoff
				b.reconnectIdleClientWithBackoff()
				continue
			}
			
			// Exit idle mode to get current status - use the dedicated idle client
			_, err = b.idleMpdClient.NoIdle()
			if err != nil {
				log.Printf("Error in MPD noidle: %v", err)
			}
			
			// Only fetch status if relevant subsystems changed
			if b.shouldUpdateStatus(changedSubsystems) {
				status, err := b.mpdClient.GetStatus() // Use the regular client for status updates
				if err != nil {
					log.Printf("Error getting MPD status: %v", err)
				} else {
					b.broadcast <- status
				}
			}
			
			// Reset ticker to start from fresh after an event
			ticker.Stop()
			ticker = time.NewTicker(60 * time.Second)
		}
	}
}

func (b *Broadcaster) shouldUpdateStatus(subsystems []string) bool {
	// Update status if any of these subsystems changed
	relevantSubsystems := map[string]bool{
		"player":    true, // playback state, elapsed time, etc.
	"mixer":     true, // volume changes
		"playlist":  true, // playlist changes
		"options":   true, // random, repeat, etc.
		"database":  true, // database updates
		"update":    true, // database updates in progress
		"stored_playlist": true, // stored playlist changes
	"output":    true, // audio output changes
	"partition": true, // partition changes
		"sticker":   true, // sticker changes
		"subscription": true, // subscription changes
		"message":   true, // message bus
	}
	
	for _, subsystem := range subsystems {
		if relevantSubsystems[subsystem] {
			return true
	}
	}
	return false
}

func (b *Broadcaster) Register(client *ClientConnection) {
	b.register <- client
}

func (b *Broadcaster) Unregister(client *ClientConnection) {
	b.unregister <- client
}

func (b *Broadcaster) Broadcast(status *models.MPDStatus) {
	b.broadcast <- status
}

func (b *Broadcaster) Stop() {
	b.cancel()
}

// GetClientsCount returns the number of currently connected clients
func (b *Broadcaster) GetClientsCount() int {
	b.mu.RLock()
	defer b.mu.RUnlock()
	return len(b.clients)
}

var upgrader = websocket.Upgrader{
	ReadBufferSize:  1024,
	WriteBufferSize: 1024,
	CheckOrigin: func(r *http.Request) bool {
		return true
	},
}

// Global broadcaster instance
var GlobalBroadcaster *Broadcaster

// Initialize the broadcaster when the package is loaded
func init() {
	GlobalBroadcaster = NewBroadcaster()
	go GlobalBroadcaster.Run()
}

func WebsocketHandler(w http.ResponseWriter, r *http.Request) {
	conn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		log.Printf("WebSocket upgrade error: %v", err)
		return
	}
	defer conn.Close()

	client := &ClientConnection{
		conn: conn,
	send: make(chan *models.MPDStatus, 256), // Buffered channel to handle bursts
	}

	// Register the client with the broadcaster
	GlobalBroadcaster.Register(client)

	// Start goroutine to send messages to the client
	go func() {
		defer func() {
			GlobalBroadcaster.Unregister(client)
			conn.Close()
		}()
		
		for {
			select {
			case status, ok := <-client.send:
				if !ok {
					// Channel closed, exit goroutine
					return
				}
				
				conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
				if err := conn.WriteJSON(status); err != nil {
					log.Printf("WebSocket write error: %v", err)
					return
				}
				
				// Add a small delay to prevent overwhelming the client
				time.Sleep(10 * time.Millisecond)
			}
		}
	}()

	// Keep the connection alive by handling ping/pong
	conn.SetReadDeadline(time.Now().Add(60 * time.Second))
	conn.SetPongHandler(func(string) error {
		conn.SetReadDeadline(time.Now().Add(60 * time.Second))
		return nil
	})
	
	for {
		_, _, err := conn.ReadMessage()
		if err != nil {
			log.Printf("WebSocket read error: %v", err)
			GlobalBroadcaster.Unregister(client)
			break
		}
	}
}

func LogWebsocketHandler(w http.ResponseWriter, r *http.Request) {
	conn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
	return
	}
	defer conn.Close()

	// Placeholder for log streaming
	ticker := time.NewTicker(2 * time.Second)
	defer ticker.Stop()

	for range ticker.C {
		if err := conn.WriteJSON(map[string]interface{}{
			"type": "logs",
			"data": []interface{}{},
		}); err != nil {
			break
		}
	}
}

// ensureIdleClientConnection ensures the idle client is connected
func (b *Broadcaster) ensureIdleClientConnection() {
	if !b.idleMpdClient.IsConnected() {
		if err := b.idleMpdClient.EnsureConnection(); err != nil {
			log.Printf("Failed to connect idle client: %v", err)
			b.idleClientConnected = false
		} else {
			b.idleClientConnected = true
		}
	}
}

// reconnectIdleClientWithBackoff attempts to reconnect the idle client with exponential backoff
func (b *Broadcaster) reconnectIdleClientWithBackoff() {
	// Exponential backoff: 3s, 10s, 30s, then 60s
	retryIntervals := []time.Duration{3 * time.Second, 10 * time.Second, 30 * time.Second, 60 * time.Second}
	
	for i, interval := range retryIntervals {
		select {
		case <-b.ctx.Done():
			return
		default:
			log.Printf("Attempting to reconnect idle client (attempt %d)", i+1)
			
			// Close the current connection if it exists
			b.idleMpdClient.ResetConnection()
			
			// Try to establish a new connection
			if err := b.idleMpdClient.EnsureConnection(); err != nil {
				log.Printf("Failed to reconnect idle client: %v, retrying in %v", err, interval)
				time.Sleep(interval)
			} else {
				log.Printf("Successfully reconnected idle client")
				b.idleClientConnected = true
				return // Successfully reconnected
			}
		}
	}
	
	// If all retries failed, keep trying every minute
	log.Printf("All reconnection attempts failed, continuing with periodic retries")
	ticker := time.NewTicker(60 * time.Second)
	defer ticker.Stop()
	
	for {
		select {
		case <-b.ctx.Done():
			return
		case <-ticker.C:
			log.Printf("Attempting periodic idle client reconnection")
			
			// Close the current connection if it exists
			b.idleMpdClient.ResetConnection()
			
			if err := b.idleMpdClient.EnsureConnection(); err != nil {
				log.Printf("Periodic reconnection failed: %v", err)
			} else {
				log.Printf("Successfully reconnected idle client after periodic attempt")
				b.idleClientConnected = true
				return
			}
		}
	}
}
