package api

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"sort"
	"strings"

	"mpd-client-modern/internal/config"
	"mpd-client-modern/internal/coverart"
	"mpd-client-modern/internal/metadata"
	"mpd-client-modern/internal/models"
	"mpd-client-modern/internal/mpd"
	"mpd-client-modern/internal/search"
	"mpd-client-modern/internal/sync"
	"github.com/gorilla/mux"
)

func RegisterRoutes(r *mux.Router) {
	fmt.Println("Registering API routes...")
	api := r.PathPrefix("/api").Subrouter()

	// Config
	api.HandleFunc("/config", GetConfig).Methods("GET")
	api.HandleFunc("/config", UpdateConfig).Methods("POST")
	api.HandleFunc("/connection-status", GetConnectionStatus).Methods("GET")

	// MPD Status
	api.HandleFunc("/status", GetStatus).Methods("GET")

	// Playback Controls
	api.HandleFunc("/play", Play).Methods("POST")
	api.HandleFunc("/pause", Pause).Methods("POST")
	api.HandleFunc("/stop", Stop).Methods("POST")
	api.HandleFunc("/next", Next).Methods("POST")
	api.HandleFunc("/previous", Previous).Methods("POST")
	api.HandleFunc("/volume/{volume}", SetVolume).Methods("POST")

	// Search
	api.HandleFunc("/search/fuzzy", FuzzySearch).Methods("GET")
	api.HandleFunc("/search/enhanced", EnhancedSearch).Methods("GET")

	// Sync
	api.HandleFunc("/sync/status", GetSyncStatus).Methods("GET")
	api.HandleFunc("/sync/start", StartSync).Methods("POST")

	// Albums & Artists
	api.HandleFunc("/albums", ListAlbums).Methods("GET")
	api.HandleFunc("/artists", ListArtists).Methods("GET")
	api.HandleFunc("/album/{artist}/{album}/tags", GetAlbumTags).Methods("GET")
	api.HandleFunc("/album/{artist}/{album}/tags", UpdateAlbumTags).Methods("POST")

	// Metadata
	api.HandleFunc("/metadata/search", SearchMetadata).Methods("GET")

	// Cover Art
	api.HandleFunc("/coverart/candidates", GetCoverArtCandidates).Methods("GET")
	api.HandleFunc("/coverart/apply", ApplyCoverArt).Methods("POST")

	// WebSockets
	r.HandleFunc("/ws", WebsocketHandler)
	r.HandleFunc("/ws/logs", LogWebsocketHandler)
	
	// Status refresh (for explicit user requests)
	api.HandleFunc("/status/refresh", RefreshStatus).Methods("POST")
}

func GetConfig(w http.ResponseWriter, r *http.Request) {
	SendJSON(w, models.APIResponse{Success: true, Data: config.Get()})
}

func UpdateConfig(w http.ResponseWriter, r *http.Request) {
	// Check if request body is empty
	bodyBytes := []byte{}
	if r.Body != nil {
		bodyBytes, _ = io.ReadAll(r.Body)
	}
	
	if len(bodyBytes) == 0 {
		SendError(w, http.StatusBadRequest, "Request body is empty")
		return
	}
	
	// Restore the body for decoding
	r.Body = io.NopCloser(bytes.NewReader(bodyBytes))
	
	var cfg config.Config
	if err := json.NewDecoder(r.Body).Decode(&cfg); err != nil {
		SendError(w, http.StatusBadRequest, "Invalid JSON: "+err.Error())
		return
	}
	if err := cfg.Validate(); err != nil {
		SendError(w, http.StatusBadRequest, err.Error())
		return
	}
	if err := config.Save(&cfg); err != nil {
	SendError(w, http.StatusInternalServerError, err.Error())
		return
	}
	
	// Reset the MPD client to use the new configuration in a goroutine to avoid blocking
	go func() {
		mpd.ResetClient()
	}()
	
	SendJSON(w, models.APIResponse{Success: true, Data: cfg})
}

// GetConnectionStatus returns the current connection status to the MPD server
func GetConnectionStatus(w http.ResponseWriter, r *http.Request) {
	client := mpd.GetClient()
	
	isConnected := client.IsConnected()
	
	SendJSON(w, models.APIResponse{
		Success: true,
		Data: map[string]interface{}{
			"connected": isConnected,
			"config": config.Get(),
		},
	})
}

func GetStatus(w http.ResponseWriter, r *http.Request) {
	status, err := mpd.GetClient().GetStatus()
	if err != nil {
		SendError(w, http.StatusInternalServerError, err.Error())
		return
	}
	SendJSON(w, models.APIResponse{Success: true, Data: status})
}

func RefreshStatus(w http.ResponseWriter, r *http.Request) {
	// Get current status
	status, err := mpd.GetClient().GetStatus()
	if err != nil {
		SendError(w, http.StatusInternalServerError, err.Error())
		return
	}
	
	// Broadcast to all WebSocket clients if broadcaster is available
	if GlobalBroadcaster != nil {
		GlobalBroadcaster.Broadcast(status)
	}
	
	SendJSON(w, models.APIResponse{Success: true, Data: status})
}

func FuzzySearch(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query().Get("q")
	if len(query) < 3 {
		SendJSON(w, models.APIResponse{Success: true, Data: []models.Album{}})
		return
	}
	results, err := search.FuzzySearch(r.Context(), query)
	if err != nil {
		SendError(w, http.StatusInternalServerError, err.Error())
		return
	}
	SendJSON(w, models.APIResponse{Success: true, Data: results})
}

func GetSyncStatus(w http.ResponseWriter, r *http.Request) {
	status := sync.GetManager().GetStatus()
	SendJSON(w, models.APIResponse{Success: true, Data: status})
}

func StartSync(w http.ResponseWriter, r *http.Request) {
	if err := sync.GetManager().StartSync(r.Context()); err != nil {
		SendError(w, http.StatusConflict, err.Error())
		return
	}
	SendJSON(w, models.APIResponse{Success: true})
}

func ListAlbums(w http.ResponseWriter, r *http.Request) {
	page := parseInt(r.URL.Query().Get("page"))
	if page <= 0 {
		page = 1
	}
	limit := parseInt(r.URL.Query().Get("limit"))
	if limit <= 0 || limit > 10 {
		limit = 50
	}

	sortByDate := r.URL.Query().Get("sort") == "date"

	var allAlbums []models.Album
	var err error

	if sortByDate {
		// Get all albums and sort by date
		allAlbums, err = getAllAlbumsByDate()
	} else {
		// Get all albums and sort by name
		allAlbums, err = getAllAlbumsByName()
	}

	if err != nil {
		SendError(w, http.StatusInternalServerError, err.Error())
		return
	}

	// Apply pagination
	start := (page - 1) * limit
	end := start + limit
	var paginatedAlbums []models.Album
	if start >= len(allAlbums) {
		paginatedAlbums = []models.Album{}
	} else if end > len(allAlbums) {
		paginatedAlbums = allAlbums[start:]
	} else {
		paginatedAlbums = allAlbums[start:end]
	}

	// Calculate pagination metadata based on the actual total count
	total := len(allAlbums)
	hasMore := end < total

	meta := models.PaginationMeta{
		Page:    page,
		Limit:   limit,
		Total:   total,
		HasMore: hasMore,
	}
	if hasMore {
		nextPage := page + 1
		meta.NextPage = &nextPage
	}
	if page > 1 {
		prevPage := page - 1
		meta.PrevPage = &prevPage
	}

	SendJSON(w, models.APIResponse{Success: true, Data: paginatedAlbums, Meta: meta})
}

func ListArtists(w http.ResponseWriter, r *http.Request) {
	page := parseInt(r.URL.Query().Get("page"))
	if page <= 0 {
		page = 1
	}
	limit := parseInt(r.URL.Query().Get("limit"))
	if limit <= 0 || limit > 100 {
		limit = 50
	}

	// Get all artists from MPD
	resp, err := mpd.GetClient().SendCommand("list artist")
	if err != nil {
		SendError(w, http.StatusInternalServerError, err.Error())
		return
	}

	lines := strings.Split(strings.TrimSpace(resp), "\n")
	artists := make([]string, 0)

	for _, line := range lines {
		if line != "" && strings.HasPrefix(line, "Artist: ") {
			artist := strings.TrimPrefix(line, "Artist: ")
			if artist != "" && artist != "Unknown" {
				artists = append(artists, artist)
			}
		}
	}

	// Sort artists alphabetically
	sort.Strings(artists)

	// Apply pagination
	start := (page - 1) * limit
	end := start + limit
	var paginatedArtists []string
	if start >= len(artists) {
		paginatedArtists = []string{}
	} else if end > len(artists) {
		paginatedArtists = artists[start:]
	} else {
		paginatedArtists = artists[start:end]
	}

	// Calculate pagination metadata based on the actual total count
	total := len(artists)
	hasMore := end < total

	meta := models.PaginationMeta{
		Page:    page,
		Limit:   limit,
		Total:   total,
		HasMore: hasMore,
	}
	if hasMore {
		nextPage := page + 1
		meta.NextPage = &nextPage
	}
	if page > 1 {
		prevPage := page - 1
		meta.PrevPage = &prevPage
	}

	SendJSON(w, models.APIResponse{Success: true, Data: paginatedArtists, Meta: meta})
}

func EnhancedSearch(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query().Get("q")
	page := parseInt(r.URL.Query().Get("page"))
	if page <= 0 {
		page = 1
	}
	limit := parseInt(r.URL.Query().Get("limit"))
	if limit <= 0 || limit > 100 {
		limit = 30
	}

	if len(query) < 2 {
		SendJSON(w, models.APIResponse{Success: true, Data: []models.Album{}})
		return
	}

	results, err := search.EnhancedFuzzySearch(r.Context(), query, page, limit)
	if err != nil {
	SendError(w, http.StatusInternalServerError, err.Error())
		return
	}

	// Calculate pagination metadata
	total := len(results)
	hasMore := (page * limit) < total
	nextPage := page + 1
	if !hasMore {
		nextPage = 0 // indicate no more pages
	}

	meta := models.PaginationMeta{
		Page:    page,
		Limit:   limit,
		Total:   total,
		HasMore: hasMore,
	}
	if nextPage > 0 {
		meta.NextPage = &nextPage
	}
	if page > 1 {
		prevPage := page - 1
		meta.PrevPage = &prevPage
	}

	SendJSON(w, models.APIResponse{Success: true, Data: results, Meta: meta})
}

func GetAlbumTags(w http.ResponseWriter, r *http.Request) {
	SendJSON(w, models.APIResponse{Success: true, Data: []models.Song{}})
}

func UpdateAlbumTags(w http.ResponseWriter, r *http.Request) {
	SendJSON(w, models.APIResponse{Success: true})
}

func SearchMetadata(w http.ResponseWriter, r *http.Request) {
	artist := r.URL.Query().Get("artist")
	album := r.URL.Query().Get("album")
	
	provider := metadata.NewDiscogsProvider()
	candidates, err := provider.Search(artist, album)
	if err != nil {
		SendError(w, http.StatusInternalServerError, err.Error())
		return
	}
	SendJSON(w, models.APIResponse{Success: true, Data: candidates})
}

func GetCoverArtCandidates(w http.ResponseWriter, r *http.Request) {
	artist := r.URL.Query().Get("artist")
	album := r.URL.Query().Get("album")
	
	manager := coverart.NewManager()
	candidates, err := manager.FetchCandidates(artist, album)
	if err != nil {
		SendError(w, http.StatusInternalServerError, err.Error())
		return
	}
	SendJSON(w, models.APIResponse{Success: true, Data: candidates})
}

func ApplyCoverArt(w http.ResponseWriter, r *http.Request) {
	var req struct {
		AlbumPath string `json:"albumPath"`
		ImageURL  string `json:"imageUrl"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		SendError(w, http.StatusBadRequest, "Invalid JSON")
		return
	}
	
	manager := coverart.NewManager()
	if err := manager.ApplyCover(req.AlbumPath, req.ImageURL); err != nil {
		SendError(w, http.StatusInternalServerError, err.Error())
		return
	}
	SendJSON(w, models.APIResponse{Success: true})
}

// Playback Control Handlers
func Play(w http.ResponseWriter, r *http.Request) {
	_, err := mpd.GetClient().SendCommand("play")
	if err != nil {
	SendError(w, http.StatusInternalServerError, err.Error())
		return
	}
	SendJSON(w, models.APIResponse{Success: true})
}

func Pause(w http.ResponseWriter, r *http.Request) {
	_, err := mpd.GetClient().SendCommand("pause")
	if err != nil {
		SendError(w, http.StatusInternalServerError, err.Error())
		return
	}
	SendJSON(w, models.APIResponse{Success: true})
}

func Stop(w http.ResponseWriter, r *http.Request) {
	_, err := mpd.GetClient().SendCommand("stop")
	if err != nil {
		SendError(w, http.StatusInternalServerError, err.Error())
		return
	}
	SendJSON(w, models.APIResponse{Success: true})
}

func Next(w http.ResponseWriter, r *http.Request) {
	_, err := mpd.GetClient().SendCommand("next")
	if err != nil {
		SendError(w, http.StatusInternalServerError, err.Error())
		return
	}
	SendJSON(w, models.APIResponse{Success: true})
}

func Previous(w http.ResponseWriter, r *http.Request) {
	_, err := mpd.GetClient().SendCommand("previous")
	if err != nil {
		SendError(w, http.StatusInternalServerError, err.Error())
		return
	}
	SendJSON(w, models.APIResponse{Success: true})
}

func SetVolume(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	volume := vars["volume"]
	
	_, err := mpd.GetClient().SendCommand(fmt.Sprintf("setvol %s", volume))
	if err != nil {
		SendError(w, http.StatusInternalServerError, err.Error())
		return
	}
	SendJSON(w, models.APIResponse{Success: true})
}

// Helper functions
func getAllAlbumsByDate() ([]models.Album, error) {
	client := mpd.GetClient()

	// Get all albums from MPD using list command which should work with grouped results
	resp, err := client.SendCommand("list album group artist group date")
	if err != nil {
		return nil, err
	}

	// If the above doesn't work, try a different approach
	if resp == "" || strings.TrimSpace(resp) == "OK" {
		// Fallback to using find with empty album filter to get all entries with album info
		resp, err = client.SendCommand("find album \"\"")
		if err != nil {
			return nil, err
		}
	}

	lines := strings.Split(strings.TrimSpace(resp), "\n")
	albumMap := make(map[string]*models.Album)

	var currentAlbum *models.Album
	for _, line := range lines {
		if line == "" {
			continue
	}

		parts := strings.SplitN(line, ": ", 2)
		if len(parts) != 2 {
			continue
		}

		key := parts[0]
		value := parts[1]

		switch key {
		case "Album":
			if currentAlbum != nil {
				// Save the previous album
				albumKey := currentAlbum.Album + "###" + currentAlbum.Artist
				albumMap[albumKey] = currentAlbum
			}

			if value != "" {
				currentAlbum = &models.Album{
					Album:  value,
					Artist: "",
					Date:   "",
				}
			} else {
				currentAlbum = nil
			}
	case "Artist", "AlbumArtist":
			if currentAlbum != nil {
				currentAlbum.Artist = value
			}
	case "Date":
			if currentAlbum != nil {
				currentAlbum.Date = value
			}
	}
	}

	// Add the last album
	if currentAlbum != nil {
	albumKey := currentAlbum.Album + "###" + currentAlbum.Artist
		albumMap[albumKey] = currentAlbum
	}

	// Convert map to slice
	albums := make([]models.Album, 0, len(albumMap))
	for _, album := range albumMap {
		albums = append(albums, *album)
	}

	// Sort by date (newest first)
	sort.Slice(albums, func(i, j int) bool {
		return albums[i].Date > albums[j].Date
	})

	return albums, nil
}

func getAllAlbumsByName() ([]models.Album, error) {
	client := mpd.GetClient()

	// Get all albums from MPD using list command which should work with grouped results
	resp, err := client.SendCommand("list album group artist")
	if err != nil {
		return nil, err
	}

	// If the above doesn't work, try a different approach
	if resp == "" || strings.TrimSpace(resp) == "OK" {
		// Fallback to using find with empty album filter to get all entries with album info
	resp, err = client.SendCommand("find album \"\"")
	if err != nil {
			return nil, err
		}
	}

	lines := strings.Split(strings.TrimSpace(resp), "\n")
	albumMap := make(map[string]*models.Album)

	var currentAlbum *models.Album
	for _, line := range lines {
		if line == "" {
			continue
		}

		parts := strings.SplitN(line, ": ", 2)
		if len(parts) != 2 {
			continue
		}

		key := parts[0]
		value := parts[1]

		switch key {
	case "Album":
			if currentAlbum != nil {
				// Save the previous album
				albumKey := currentAlbum.Album + "###" + currentAlbum.Artist
				albumMap[albumKey] = currentAlbum
			}

			if value != "" {
				currentAlbum = &models.Album{
					Album:  value,
					Artist: "",
				}
			} else {
				currentAlbum = nil
			}
	case "Artist", "AlbumArtist":
			if currentAlbum != nil {
				currentAlbum.Artist = value
			}
		}
	}

	// Add the last album
	if currentAlbum != nil {
		albumKey := currentAlbum.Album + "###" + currentAlbum.Artist
		albumMap[albumKey] = currentAlbum
	}

	// Convert map to slice
	albums := make([]models.Album, 0, len(albumMap))
	for _, album := range albumMap {
		albums = append(albums, *album)
	}

	// Sort by album name
	sort.Slice(albums, func(i, j int) bool {
		return albums[i].Album < albums[j].Album
	})

	return albums, nil
}

func getAlbumsPaginated(page, limit int) ([]models.Album, error) {
	allAlbums, err := getAllAlbumsByName()
	if err != nil {
		return nil, err
	}

	// Apply pagination
	start := (page - 1) * limit
	end := start + limit
	if start >= len(allAlbums) {
		return []models.Album{}, nil
	} else if end > len(allAlbums) {
		return allAlbums[start:], nil
	} else {
		return allAlbums[start:end], nil
	}
}

func parseInt(s string) int {
	var i int
	fmt.Sscanf(s, "%d", &i)
	return i
}

// Helpers
func SendJSON(w http.ResponseWriter, data interface{}) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(data)
}

func SendError(w http.ResponseWriter, code int, message string) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(models.APIResponse{Success: false, Error: message})
}
