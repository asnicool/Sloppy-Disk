package search

import (
	"testing"
	"mpd-client-modern/internal/models"
)

func TestProcessSong(t *testing.T) {
	albumMap := make(map[string]*models.Album)
	var titles []string

	song1 := map[string]string{
		"Album": "Dark Side of the Moon",
		"Artist": "Pink Floyd",
	}
	processSong(song1, albumMap, &titles)

	if len(albumMap) != 1 {
		t.Errorf("Expected 1 album, got %d", len(albumMap))
	}

	key := "Dark Side of the Moon - Pink Floyd"
	if _, ok := albumMap[key]; !ok {
		t.Errorf("Expected key %s not found", key)
	}

	// Add another song from same album
	song2 := map[string]string{
		"Album": "Dark Side of the Moon",
		"Artist": "Pink Floyd",
	}
	processSong(song2, albumMap, &titles)

	if len(albumMap) != 1 {
		t.Errorf("Expected still 1 album, got %d", len(albumMap))
	}
}
