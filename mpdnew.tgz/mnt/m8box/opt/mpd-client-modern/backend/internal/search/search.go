package search

import (
	"context"
	"fmt"
	"strings"

	"mpd-client-modern/internal/models"
	"mpd-client-modern/internal/mpd"
	"github.com/sahilm/fuzzy"
)

type SearchResult struct {
	Album  models.Album
	Score  int
}

func FuzzySearch(ctx context.Context, query string) ([]models.Album, error) {
	client := mpd.GetClient()
	
	// 1. Broad search in MPD
	// We search for tracks matching the query in any tag
	cmd := fmt.Sprintf("search any \"%s\"", strings.ReplaceAll(query, "\"", "\\\""))
	resp, err := client.SendCommand(cmd)
	if err != nil {
		return nil, err
	}

	// 2. Parse tracks and group by album
	lines := strings.Split(strings.TrimSpace(resp), "\n")
	albumMap := make(map[string]*models.Album)
	var albumTitles []string

	var currentSong map[string]string
	for _, line := range lines {
		if line == "" {
			if currentSong != nil {
				processSong(currentSong, albumMap, &albumTitles)
				currentSong = nil
			}
			continue
		}
		parts := strings.SplitN(line, ": ", 2)
		if len(parts) == 2 {
			if currentSong == nil {
				currentSong = make(map[string]string)
			}
			currentSong[parts[0]] = parts[1]
		}
	}
	if currentSong != nil {
		processSong(currentSong, albumMap, &albumTitles)
	}

	// 3. Fuzzy match album titles and artists
	matches := fuzzy.Find(query, albumTitles)
	
	var results []models.Album
	seen := make(map[string]bool)
	for _, match := range matches {
		album := albumMap[match.Str]
		if album != nil && !seen[album.Album+album.Artist] {
			results = append(results, *album)
			seen[album.Album+album.Artist] = true
		}
	}

	return results, nil
}

func processSong(songAttrs map[string]string, albumMap map[string]*models.Album, titles *[]string) {
	albumName := songAttrs["Album"]
	artistName := songAttrs["Artist"]
	if albumName == "" {
		albumName = "Unknown Album"
	}
	
	key := albumName + " - " + artistName
	if _, ok := albumMap[key]; !ok {
		album := &models.Album{
			Album:  albumName,
			Artist: artistName,
			Title:  albumName,
		}
		albumMap[key] = album
		*titles = append(*titles, key)
		*titles = append(*titles, albumName)
		*titles = append(*titles, artistName)
	}
}

func EnhancedFuzzySearch(ctx context.Context, query string, page, limit int) ([]models.Album, error) {
	client := mpd.GetClient()
	
	// 1. Broad search in MPD for tracks matching the query in any tag
	cmd := fmt.Sprintf("search any \"%s\"", strings.ReplaceAll(query, "\"", "\\\""))
	resp, err := client.SendCommand(cmd)
	if err != nil {
		return nil, err
	}

	// 2. Parse tracks and group by album
	lines := strings.Split(strings.TrimSpace(resp), "\n")
	albumMap := make(map[string]*models.Album)
	var albumTitles []string

	var currentSong map[string]string
	for _, line := range lines {
		if line == "" {
			if currentSong != nil {
				processSong(currentSong, albumMap, &albumTitles)
				currentSong = nil
			}
			continue
		}
		parts := strings.SplitN(line, ": ", 2)
		if len(parts) == 2 {
			if currentSong == nil {
				currentSong = make(map[string]string)
			}
			currentSong[parts[0]] = parts[1]
		}
	}
	if currentSong != nil {
		processSong(currentSong, albumMap, &albumTitles)
	}

	// 3. Fuzzy match album titles and artists
	matches := fuzzy.Find(query, albumTitles)
	
	// 4. Convert matches to albums with scores
	var results []models.Album
	seen := make(map[string]bool)
	for _, match := range matches {
		album := albumMap[match.Str]
		if album != nil && !seen[album.Album+album.Artist] {
			results = append(results, *album)
			seen[album.Album+album.Artist] = true
		}
	}

	// 5. Apply pagination
	start := (page - 1) * limit
	end := start + limit
	if start >= len(results) {
		return []models.Album{}, nil
	} else if end > len(results) {
		return results[start:], nil
	} else {
		return results[start:end], nil
	}
}
